<script setup lang="ts">
definePageMeta({ documentDriven: false })
useSeoMeta({ title: 'História do site — Marçal', description: 'As edições visuais do site de Vítor Marçal, preservadas ao longo do tempo.' })
</script>

<template>
  <main class="editions-page">
    <p class="eyebrow">O arquivo do próprio arquivo</p>
    <h1>História do site</h1>
    <p>Um site pessoal também é um retrato de quem o faz. Aqui ficam guardadas as suas diferentes edições.</p>
    <p>Você pode navegar pelo conteúdo atual usando cada visual. O arquivo de código da edição original registra o código antes da mudança de 24 de outubro de 2026 (as imagens do acervo continuam nos seus endereços originais).</p>
    <article class="edition-card">
      <div class="edition-swatch revista" aria-hidden="true">Marçal. ◆</div>
      <h2>02 — Revista pessoal</h2>
      <p>Outubro de 2026 · Papel, tinta e outras obsessões. Uma edição inspirada em revistas e acervos culturais, com livros, cinema e música na mesma estante.</p>
      <NuxtLink to="/arquivo/revista-2026">Visitar esta edição ↗</NuxtLink>
      <a href="/arquivo/revista-2026.tar.gz" download>Baixar o código preservado ↓</a>
    </article>
    <article class="edition-card">
      <div class="edition-swatch original" aria-hidden="true">Marçal</div>
      <h2>01 — Preto & verde</h2>
      <p>Preservada em outubro de 2026 · Fundo preto, links verdes e o texto em primeiro plano. O visual anterior, guardado como parte desta história.</p>
      <NuxtLink to="/arquivo/original">Visitar esta edição ↗</NuxtLink>
      <a href="/arquivo/original-2026-10-24.tar.gz" download>Baixar o código preservado ↓</a>
    </article>
  </main>
</template>
