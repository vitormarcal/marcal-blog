<script setup lang="ts">
import { formatDate } from '~/utils/date-utils'
const { data: posts } = await useAsyncData('revista-2026-home', () => queryContent()
  .where({ is_post: true, _partial: false }).sort({ created_at: -1 }).limit(5).without(['body']).find())
const featured = computed(() => posts.value?.[0])
const remaining = computed(() => posts.value?.slice(1) || [])
const { stories } = useStoriesCatalog()
useSeoMeta({ title: 'Marçal — Notas, cultura & outras obsessões', description: 'O arquivo pessoal de Vítor Marçal. Leituras, cinema, música e ideias que merecem ficar.' })
const shelf = [
  { title: 'Fundação', subtitle: 'Isaac Asimov', image: '/leituras/fundacao/img/fundacao.png', path: '/leituras/fundacao/fundacao' },
  { title: 'O alienista', subtitle: 'Machado de Assis', image: '/leituras/o-alienista/o-alienista.jpg', path: '/leituras/o-alienista/o-alienista' },
  { title: 'O gene egoísta', subtitle: 'Richard Dawkins', image: '/leituras/img/o-gene-egoista-por-richard-dawkins.jpg', path: '/leituras/o-gene-egoista-por-richard-dawkins' }
]
</script>

<template>
  <main class="editorial-home">
    <div class="edition-line"><span>Caderno aberto · Edição 2026</span><span>Por Vítor Marçal</span></div>
    <section class="editorial-intro"><p class="eyebrow">Entre uma página e outra</p><h1>Coisas que ficam<br />na <em>cabeça.</em></h1><p>Livros sublinhados, filmes que voltam, músicas em repetição. Escrevo para mim mesmo — e deixo a porta aberta.</p></section>
    <div class="front-page-grid">
      <section class="lead-story" aria-labelledby="latest-title"><div class="section-rule"><h2 id="latest-title">Últimas publicações</h2><span>01 / Caderno de notas</span></div>
        <article v-if="featured" class="featured-post"><p class="eyebrow">A publicação mais recente <span>↘</span></p><NuxtLink :to="featured._path"><h3>{{ featured.title }}</h3></NuxtLink><p>{{ featured.description }}</p><div class="post-byline"><time :datetime="featured.created_at">{{ formatDate(featured.created_at) }}</time><NuxtLink :to="featured._path">Ler a publicação ↗</NuxtLink></div></article>
        <p v-else class="empty-notes">O caderno está aberto. As publicações aparecerão por aqui.</p>
        <div class="short-posts"><article v-for="(post, index) in remaining" :key="post._path"><span class="post-number">0{{ index + 2 }}</span><div><time :datetime="post.created_at">{{ formatDate(post.created_at) }}</time><h3><NuxtLink :to="post._path">{{ post.title }}</NuxtLink></h3><p>{{ post.description }}</p></div></article></div>
        <NuxtLink class="archive-link" to="/publicacoes">Abrir o arquivo de publicações <span>↗</span></NuxtLink>
      </section>
      <aside class="personal-column" aria-label="Pelo acervo"><div class="section-rule"><h2>Na estante</h2><span>02 / Leituras</span></div><p class="shelf-note">Algumas companhias do meu acervo.</p><div class="book-shelf"><NuxtLink v-for="book in shelf" :key="book.path" :to="book.path" class="shelf-book"><div class="book-cover"><img :src="book.image" :alt="'Capa de ' + book.title" width="240" height="360" loading="lazy" /></div><h3>{{ book.title }}</h3><p>{{ book.subtitle }}</p></NuxtLink></div><NuxtLink class="small-link" to="/leituras/2026">O diário de leituras ↗</NuxtLink>
      <div class="field-note"><span class="eyebrow">Nota à margem</span><p>Este site é meu segundo cérebro. Um lugar para guardar o que encontro pelo caminho.</p><NuxtLink to="/sobre">Muito prazer, Vítor ↗</NuxtLink></div>
      <div class="culture-index"><h2>Outras frequências</h2><NuxtLink to="/filmes">No escuro do cinema <span>↗</span></NuxtLink><NuxtLink to="/musicas">Deixa o som tocar <span>↗</span></NuxtLink><NuxtLink to="/series">Só mais um episódio <span>↗</span></NuxtLink><NuxtLink to="/gostos">Um mapa dos meus gostos <span>↗</span></NuxtLink></div></aside>
    </div>
    <section v-if="stories.length" class="editorial-stories"><div class="section-rule"><h2>Fragmentos do caminho</h2><span>03 / Registros</span></div><StoryRail :items="stories" /></section>
    <section class="colophon"><span class="colophon-mark" aria-hidden="true">✳</span><div><h2>O tempo também muda esta página.</h2><p>Os visuais anteriores continuam guardados. Cada edição, um retrato de uma fase.</p></div><NuxtLink to="/arquivo">Visitar a história do site ↗</NuxtLink></section>
  </main>
</template>
